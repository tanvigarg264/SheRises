const responseObj = {
  hello: "Hey ! How are you doing ?",
  hey: "Hey! What's Up",
  today: new Date().toDateString(),
  time: new Date().toLocaleTimeString(),
  1: "police:100"
};
