Detailed Explanation Video :https://youtu.be/C2bKXt1yuPE
